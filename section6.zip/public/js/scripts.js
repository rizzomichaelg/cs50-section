/**
 * scripts.js
 *
 * Section 6
 *
 * Global JavaScript, if any.
 */

<?php

    // configuration
    require("../includes/config.php"); 

    // render portfolio
    render("main.php", ["title" => "Index"]);

?>

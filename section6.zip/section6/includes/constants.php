<?php

    /**
     * constants.php
     *
     * Section 6
     *
     * Global constants.
     */

?>

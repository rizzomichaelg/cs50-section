<h3>Your Name Here</h3>

<div>
    A little something about yourself...
</div>

<h4>Blog Posts</h4>
<div>
    <?php 
        // TODO
        echo 'The current date and time is: ' . date('m/d/y H:i:s');
    ?>
</div>